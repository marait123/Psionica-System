# Testing
## prerequisites 
1. you should linux shell or git bash to run the testing script
2. make sure you have curl installed on your system run `curl --version` to test if it is installed
## running the test
to test the station
* make sure that the 2 variables ssid_orange, password_orange have the same values as your router
* once the red led on the car is on start running the following commands
* run the command `chmod u+x ./test.sh`
* run the command `./test_wheelchair.sh`
