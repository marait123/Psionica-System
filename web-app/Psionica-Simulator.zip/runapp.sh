source env/bin/activate
export FLASK_APP=flaskr
export FLASK_DEBUG=1
flask run --reload --host=0.0.0.0